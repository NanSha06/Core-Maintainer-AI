"""
test_dashboard.py
-----------------
Integration and module test for CoreMaintainer ID application.
Ensures all analytics modules run correctly and visualizations render without error.
"""

import sys
import os
import traceback

# Add src to import path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "src")))

from src.github_data import fetch_github_data
from src.analytics import (
    network_metrics,
    health_score,
    pr_issue_analysis,
    maintainer_clustering,
    predictive_insights,
    repo_health,
    reviewer_network,
    time_series,
    dashboard_tabs
)


def divider(title):
    print("\n" + "=" * 60)
    print(f"🔹 {title}")
    print("=" * 60)


def test_repo_data():
    divider("Fetching GitHub Repository Data")
    try:
        repo_data = fetch_github_data("pytorch/pytorch")
        assert isinstance(repo_data, dict) and repo_data.get("stars", 0) >= 0
        print("✅ Repository data fetched successfully:")
        print(repo_data)
        return repo_data
    except Exception as e:
        print("❌ Error while fetching repo data:", e)
        traceback.print_exc()


def test_all_analytics(repo_data):
    divider("Testing Individual Analytics Modules")

    try:
        print("📊 Network Metrics...")
        network_metrics.show_network_metrics(repo_data)
        print("✅ Network metrics visualization rendered successfully.\n")

        print("💚 Health Score...")
        health_score.show_health_score(repo_data)
        print("✅ Health score visualization rendered successfully.\n")

        print("🐞 PR & Issue Analysis...")
        pr_issue_analysis.show_pr_issue_analysis(repo_data)
        print("✅ PR/Issue visualization rendered successfully.\n")

        print("🧩 Maintainer Clustering...")
        maintainer_clustering.show_maintainer_clustering(repo_data)
        print("✅ Maintainer clustering visualization rendered successfully.\n")

        print("🕒 Time Series...")
        time_series.show_time_series(repo_data)
        print("✅ Time series visualization rendered successfully.\n")

        print("🧠 Predictive Insights...")
        predictive_insights.show_predictive_insights(repo_data)
        print("✅ Predictive insights visualization rendered successfully.\n")

        print("🔍 Reviewer Network...")
        reviewer_network.show_reviewer_network(repo_data)
        print("✅ Reviewer network visualization rendered successfully.\n")

        print("📈 Repository Health...")
        repo_health.show_repo_health(repo_data)
        print("✅ Repository health visualization rendered successfully.\n")

    except Exception as e:
        print("❌ Error during module visualization test:", e)
        traceback.print_exc()


def test_full_dashboard(repo_data):
    divider("Testing Full Dashboard Integration")
    try:
        dashboard_tabs.render_dashboard(repo_data)
        print("✅ Dashboard tabs rendered successfully in Streamlit.")
    except Exception as e:
        print("❌ Error while rendering full dashboard:", e)
        traceback.print_exc()


if __name__ == "__main__":
    print("🚀 Running Core Maintainer ID Test Suite")

    repo_data = test_repo_data()
    if repo_data:
        test_all_analytics(repo_data)
        test_full_dashboard(repo_data)

    print("\n✅ All modules executed successfully (if no errors shown above).")
