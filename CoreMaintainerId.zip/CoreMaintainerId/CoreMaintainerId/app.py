import streamlit as st
from src.graph_analysis import analyze_repository

st.set_page_config(page_title="🧠 Core Maintainer ID", layout="wide")
st.title("🧠 Core Maintainer ID Dashboard")

repo_name = st.text_input("Enter GitHub Repository (e.g., pytorch/pytorch):")

if st.button("Analyze Repository"):
    with st.spinner("Analyzing repository data..."):
        result = analyze_repository(repo_name)

        if "error" in result:
            st.error(result["error"])
        else:
            st.success(result["summary"])
