from src.github_data import fetch_github_data
from src.analytics.dashboard_tabs import render_dashboard


def analyze_repository(repo_name: str):
    """
    Fetch repository data and render analytics dashboard tabs.
    """
    print(f"🔍 Fetching repository data for: {repo_name}")
    repo_data = fetch_github_data(repo_name)

    if not repo_data:
        return {"error": f"Repository {repo_name} not found."}

    render_dashboard(repo_data)

    return {
        "repo_name": repo_name,
        "summary": f"Analysis completed successfully for {repo_name}."
    }
