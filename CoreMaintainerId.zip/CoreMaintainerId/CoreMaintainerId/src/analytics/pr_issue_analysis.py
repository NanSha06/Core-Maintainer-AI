import streamlit as st
import matplotlib.pyplot as plt


def show_pr_issue_analysis(repo_data):
    st.subheader("🐞 Pull Request & Issue Analysis")

    pr_count = repo_data.get("recent_commits", 0)
    issues = repo_data.get("open_issues", 0)

    fig, ax = plt.subplots()
    ax.pie(
        [pr_count, issues],
        labels=["Pull Requests", "Open Issues"],
        autopct="%1.1f%%",
        colors=["#0077b6", "#d62828"],
        startangle=90
    )
    plt.title("PRs vs Issues Distribution")
    st.pyplot(fig)
