import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans


def show_maintainer_clustering(repo_data):
    st.subheader("🧩 Maintainer Clustering Analysis")

    contributors = repo_data.get("contributors", 10)
    X = np.random.rand(contributors, 2)

    kmeans = KMeans(n_clusters=min(3, contributors), n_init=10)
    y_pred = kmeans.fit_predict(X)

    fig, ax = plt.subplots()
    plt.scatter(X[:, 0], X[:, 1], c=y_pred, cmap="viridis", s=80)
    plt.title("Maintainer Clusters (Simulated)")
    st.pyplot(fig)
