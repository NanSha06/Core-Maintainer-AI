import streamlit as st
import matplotlib.pyplot as plt


def show_health_score(repo_data):
    st.subheader("💚 Repository Health Score")

    stars = repo_data.get("stars", 0)
    forks = repo_data.get("forks", 0)
    commits = repo_data.get("recent_commits", 0)
    contributors = repo_data.get("contributors", 0)

    score = min(100, (0.3 * stars + 0.2 * forks + 0.3 * commits + 0.2 * contributors) / 1000)
    st.metric("Health Score", f"{score:.1f}/100")

    # Gauge visualization
    color = "green" if score >= 70 else "orange" if score >= 40 else "red"
    fig, ax = plt.subplots(figsize=(3, 3))
    circle = plt.Circle((0.5, 0.5), 0.4, color=color, alpha=0.6)
    ax.add_patch(circle)
    ax.text(0.5, 0.5, f"{score:.1f}", ha="center", va="center", fontsize=22, color="white")
    ax.axis("off")
    plt.title("Health Score Indicator")
    st.pyplot(fig)
