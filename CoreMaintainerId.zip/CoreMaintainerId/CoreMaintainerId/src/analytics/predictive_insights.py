import streamlit as st
import numpy as np
import matplotlib.pyplot as plt


def show_predictive_insights(repo_data):
    st.subheader("🧠 Predictive Insights")

    x = np.arange(10)
    y = np.random.randint(5, 15, size=10)
    trend = np.poly1d(np.polyfit(x, y, 1))(x)

    fig, ax = plt.subplots()
    ax.plot(x, y, "o-", label="Past Activity")
    ax.plot(x, trend, "--", label="Predicted Trend", color="orange")
    plt.legend()
    plt.title("Predicted Repository Growth")
    st.pyplot(fig)
