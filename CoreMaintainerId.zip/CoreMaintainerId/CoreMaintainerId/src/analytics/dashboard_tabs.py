import streamlit as st
from src.analytics.network_metrics import show_network_metrics
from src.analytics.health_score import show_health_score
from src.analytics.pr_issue_analysis import show_pr_issue_analysis
from src.analytics.repo_health import show_repo_health
from src.analytics.reviewer_network import show_reviewer_network
from src.analytics.time_series import show_time_series
from src.analytics.maintainer_clustering import show_maintainer_clustering
from src.analytics.predictive_insights import show_predictive_insights


def render_dashboard(repo_data: dict):
    """
    Renders multi-tab Streamlit dashboard for analytics modules.
    """
    tabs = st.tabs([
        "📊 Network Metrics",
        "💚 Health Score",
        "🐞 PR & Issue Analysis",
        "🧩 Maintainer Clustering",
        "🕒 Time Series",
        "🧠 Predictive Insights",
        "🔍 Reviewer Network",
        "📈 Repository Health"
    ])

    with tabs[0]:
        show_network_metrics(repo_data)
    with tabs[1]:
        show_health_score(repo_data)
    with tabs[2]:
        show_pr_issue_analysis(repo_data)
    with tabs[3]:
        show_maintainer_clustering(repo_data)
    with tabs[4]:
        show_time_series(repo_data)
    with tabs[5]:
        show_predictive_insights(repo_data)
    with tabs[6]:
        show_reviewer_network(repo_data)
    with tabs[7]:
        show_repo_health(repo_data)
