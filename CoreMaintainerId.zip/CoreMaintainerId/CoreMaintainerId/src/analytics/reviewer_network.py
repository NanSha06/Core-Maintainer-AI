import streamlit as st
import networkx as nx
import matplotlib.pyplot as plt


def show_reviewer_network(repo_data):
    st.subheader("🔍 Reviewer Collaboration Network")

    reviewers = repo_data.get("contributors", 5)
    G = nx.gnm_random_graph(reviewers, max(1, reviewers // 2))

    fig, ax = plt.subplots()
    nx.draw_networkx(G, node_color="lightgreen", node_size=100, with_labels=False, ax=ax)
    plt.title("Reviewer-Author Collaboration")
    st.pyplot(fig)
