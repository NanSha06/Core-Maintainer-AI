import streamlit as st
import matplotlib.pyplot as plt


def show_repo_health(repo_data):
    st.subheader("📈 Repository Health Overview")

    metrics = {
        "Stars": repo_data.get("stars", 0),
        "Forks": repo_data.get("forks", 0),
        "Issues": repo_data.get("open_issues", 0),
        "Commits": repo_data.get("recent_commits", 0),
    }

    fig, ax = plt.subplots()
    ax.bar(metrics.keys(), metrics.values(), color=["#28a745", "#17a2b8", "#ffc107", "#dc3545"])
    plt.title("Repository Metric Overview")
    plt.xticks(rotation=30)
    st.pyplot(fig)
