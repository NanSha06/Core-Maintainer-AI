import streamlit as st
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def show_time_series(repo_data):
    st.subheader("🕒 Time Series Activity Trends")

    days = np.arange(1, 31)
    commits = np.random.randint(5, 50, size=30)
    issues = np.random.randint(2, 30, size=30)

    df = pd.DataFrame({"Commits": commits, "Issues": issues}, index=days)

    fig, ax = plt.subplots()
    df.plot(ax=ax)
    plt.title("Commit & Issue Trend (Last 30 Days)")
    plt.xlabel("Day")
    plt.ylabel("Count")
    st.pyplot(fig)
