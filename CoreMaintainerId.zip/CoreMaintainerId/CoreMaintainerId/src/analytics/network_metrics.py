import networkx as nx
import matplotlib.pyplot as plt
import streamlit as st


def show_network_metrics(repo_data):
    st.subheader("📊 Network Metrics")
    contributors = repo_data.get("contributors", 0)
    G = nx.gnm_random_graph(contributors, max(1, contributors // 2))

    density = nx.density(G)
    clustering = nx.average_clustering(G)

    metrics = {
        "Contributors": contributors,
        "Network Density": round(density, 3),
        "Average Clustering": round(clustering, 3)
    }

    st.json(metrics)

    # Visualize
    fig, ax = plt.subplots()
    nx.draw(G, node_color="skyblue", node_size=80, with_labels=False, ax=ax)
    plt.title("Contributor Network Graph")
    st.pyplot(fig)
