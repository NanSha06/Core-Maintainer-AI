import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Retrieve API keys safely
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

def get_github_token():
    if not GITHUB_TOKEN:
        print("⚠️  GitHub token not found. Limited API access will apply.")
    return GITHUB_TOKEN

def get_gemini_api_key():
    if not GEMINI_API_KEY:
        raise ValueError("❌ Gemini API key not found. Please set it in your .env file.")
    return GEMINI_API_KEY
