import streamlit as st
import pandas as pd

@st.cache_data
def cache_data(repo, df):
    return df

def handle_large_repo(df):
    if len(df) > 10000:
        st.info("Large repository detected — sampling top contributors for performance.")
        return df.sort_values("commits", ascending=False).head(10000)
    return df
