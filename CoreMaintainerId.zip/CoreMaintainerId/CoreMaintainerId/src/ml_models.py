import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score


def train_core_predictor(metrics_df: pd.DataFrame):
    """
    Basic ML model to predict 'core maintainers' based on influence metrics.
    """
    if "influence_score" not in metrics_df.columns:
        raise ValueError("Expected 'influence_score' column in metrics dataframe")

    metrics_df["is_core"] = metrics_df["influence_score"] >= metrics_df["influence_score"].mean()

    X = metrics_df[["degree", "betweenness", "closeness", "eigenvector", "clustering"]]
    y = metrics_df["is_core"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)

    return model, round(acc, 3)
