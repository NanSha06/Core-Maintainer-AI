import requests
import os
from dotenv import load_dotenv

load_dotenv()

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
HEADERS = {"Authorization": f"token {GITHUB_TOKEN}"} if GITHUB_TOKEN else {}


def fetch_github_data(repo_name: str):
    """
    Fetch GitHub repository metrics using the REST API.
    """
    try:
        base_url = f"https://api.github.com/repos/{repo_name}"
        repo_data = requests.get(base_url, headers=HEADERS).json()

        if "message" in repo_data and repo_data["message"] == "Not Found":
            raise ValueError(f"❌ Repository '{repo_name}' not found!")

        contributors_data = requests.get(repo_data["contributors_url"], headers=HEADERS).json()
        commits_data = requests.get(f"{base_url}/commits", headers=HEADERS).json()

        return {
            "name": repo_name,
            "stars": repo_data.get("stargazers_count", 0),
            "forks": repo_data.get("forks_count", 0),
            "open_issues": repo_data.get("open_issues_count", 0),
            "contributors": len(contributors_data) if isinstance(contributors_data, list) else 0,
            "recent_commits": len(commits_data) if isinstance(commits_data, list) else 0,
        }

    except Exception as e:
        print(f"⚠️ Error fetching repository data: {e}")
        return {}
