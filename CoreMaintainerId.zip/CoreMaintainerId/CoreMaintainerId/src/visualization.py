"""
visualization.py
----------------
Handles plotting and visualization for repository metrics and network statistics.
"""

import matplotlib.pyplot as plt
import networkx as nx
import io
import streamlit as st


def plot_network_graph(contributors: int, density: float):
    """
    Generate a simulated network graph visualization.
    """
    if contributors <= 1:
        st.warning("Not enough contributors to visualize a network.")
        return

    G = nx.gnm_random_graph(contributors, max(1, contributors // 2))
    fig, ax = plt.subplots(figsize=(6, 4))
    nx.draw_networkx(
        G,
        node_size=100,
        node_color="skyblue",
        edge_color="gray",
        with_labels=False,
        ax=ax,
    )
    plt.title(f"Contributor Network (Density: {density:.3f})")
    st.pyplot(fig)


def plot_metric_bars(metrics: dict):
    """
    Display metrics as a horizontal bar chart.
    """
    fig, ax = plt.subplots(figsize=(6, 4))
    keys = ["stars", "forks", "open_issues", "contributors", "recent_commits"]
    values = [metrics.get(k, 0) for k in keys]

    ax.barh(keys, values, color="#32a852")
    ax.set_xlabel("Value")
    ax.set_title("Repository Metrics Overview")
    st.pyplot(fig)


def plot_health_gauge(score: float):
    """
    Render health score as a visual gauge (color-coded).
    """
    fig, ax = plt.subplots(figsize=(3, 3))
    ax.axis("off")

    color = (
        "green" if score >= 70
        else "orange" if score >= 40
        else "red"
    )
    circle = plt.Circle((0.5, 0.5), 0.4, color=color, alpha=0.6)
    ax.add_patch(circle)
    ax.text(0.5, 0.5, f"{score:.1f}", fontsize=24, ha="center", va="center", color="white")
    plt.title("Health Score", fontsize=14)
    st.pyplot(fig)


def plot_pr_issue_analysis(pr_issues: int, open_issues: int):
    """
    Display PR/Issue comparison.
    """
    labels = ["Pull Requests", "Open Issues"]
    values = [pr_issues, open_issues]
    colors = ["#0077b6", "#d62828"]

    fig, ax = plt.subplots()
    ax.pie(values, labels=labels, colors=colors, autopct="%1.1f%%", startangle=90)
    ax.set_title("PRs vs Open Issues")
    st.pyplot(fig)
